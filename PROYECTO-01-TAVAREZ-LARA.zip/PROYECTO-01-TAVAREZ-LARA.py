###Proyecto 1 LifeStore
###Genaro Tavarez

#Exportamos las listas del file para evitar bajar las 500 lineas de código de las listas
from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

"""
This is the LifeStore-SalesList data:

lifestore-searches = [id_search, id product]
lifestore-sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore-products = [id_product, name, price, category, stock]
"""
#Login del usuario

usuarios = [["g","1"]]

acceso_usuario = input("Ingresa tu usuario: ")
acceso_passw = input("Ingresa tu contraseña: ")

admin = 0

for usuario in usuarios:
  if usuario[0] == acceso_usuario and usuario[1] == acceso_passw:
    print("Bienvenido a Lifestore")
  else:
    print("Largate intruso")


#1.1.1- Generar un listado de los 50 productos con mayores ventas
print('1.1.1- Generar un listado de los 50 productos con mayores ventas')
ventas=[]
for id_producto in lifestore_products:
  contador = 0
  for id_venta in lifestore_sales:
    if id_venta[1] == id_producto[0]:
      contador += 1
  ventas.extend([[id_producto[1],contador]])
ventas.sort(key=lambda ventita: ventita[1],reverse=True)

#Acomoda los 50 productos con más ventas
for venta in range(0, 49):  
  print(ventas[venta])
venta+=1


#1.1.2- Generar un listado con los 100 productos con mayor búsquedas. 
print('1.1.2- Generar un listado con los 100 productos con mayor búsquedas')
busquedas = []
for id_producto in lifestore_products:
  contador = 0
  for id_busqueda in lifestore_searches:
    if id_busqueda[1] == id_producto[0]:
      contador += 1
  busquedas.extend([[id_producto[1],contador]])
busquedas.sort(key=lambda busquedita: busquedita[1],reverse=True)

#Acomoda los 100 productos con más busquedas
for busqueda in range(0,90):
  print(busquedas[busqueda])
busqueda +=1


#1.2.1-Por categoría, generar un listado con los 50 productos con menores ventas
print('1.2.1- Por categoría, generar un listado con los 50 productos con menores ventas')
ventas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0]:
            contador += 1
    ventas.extend([[id_producto[3],contador]])
ventas.sort(key=lambda ventita: ventita[1], reverse = True)

#Agrupación
my_dict1 = {}
for d in ventas:
    if d[0] in my_dict1.keys():
        my_dict1[d[0]] += d[1]
    else:
        my_dict1[d[0]] = d[1]
my_list2 = [[k,v] for (k,v) in my_dict1.items()]
print(my_list2)



#1.2.2- Por categoría, generar un listado con los 100 productos con menores búsquedas.
print('1.2.2- Por categoría, generar un listado con los 100 productos con menores búsquedas.')
busquedas = []
for id_producto in lifestore_products:
  contador = 0
  var = 0
  for id_busqueda in lifestore_searches:
    if id_busqueda[1] == id_producto[0]:
      contador += 1
  busquedas.extend([[id_producto[3],contador]])
busquedas.sort(key=lambda busquedita: busquedita[1], reverse=True)

#Agrupación
my_dict1 = {}
for d in busquedas:
    if d[0] in my_dict1.keys():
        my_dict1[d[0]] += d[1]
    else:
        my_dict1[d[0]] = d[1]
my_list2 = [[k,v] for (k,v) in my_dict1.items()]
print(my_list2)



#2.1- Mostrar un listado para productos con las 20 mejores reseñas, considerando los productos de devolución
print('2.1- Mostrar un listado para productos con las 20 mejores reseñas, considerando los productos de devolución')
resenas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0] and id_venta[4] == 0:
            var += id_venta[2]
            contador += 1
    if contador == 0:        
        resenas.extend([[id_producto[1],contador, var]])
    else:
        resenas.extend([[id_producto[1],contador, round(var/contador,2)]])
resenas.sort(key=lambda ventita: ventita[2],reverse=True)
#Acomoda los 20 productos con más busquedas
for resena in range(0,19):
  print(resenas[resena])
resena +=1


#2.2- Mostrar un listado para productos con las 20 peores reseñas, considerando los productos de devolución
print('2.2- Mostrar un listado para productos con las 20 peores reseñas, considerando los productos de devolución')
resenas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0] and id_venta[4] == 0:
            var += id_venta[2]
            contador += 1
    if contador == 0:        
        resenas.extend([[id_producto[1],contador, var]])
    else:
        resenas.extend([[id_producto[1],contador, round(var/contador,2)]])
resenas.sort(key=lambda ventita: ventita[2])
#Acomoda los 20 productos con más busquedas
for resena in range(0,19):
  print(resenas[resena])
resena +=1


#3.1- Total de ingresos y ventas promedio mensuales
print('3.1- Total de ingresos y ventas promedio mensuales')
ventas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0]:
            var += id_venta[2]
            contador += 1
            if contador == 0:        
                ventas.extend([[id_venta[3][3:5], id_producto[2], var]])
            else:
                ventas.extend([[id_venta[3][3:5], id_producto[2], round(var/contador,2)]])
ventas.sort(key=lambda ventita: ventita[0])

my_dict1 = {}
for d in ventas:
    if d[0] in my_dict1.keys():
        my_dict1[d[0]] += d[1]
    else:
        my_dict1[d[0]] = d[1]
my_list2 = [[k,v] for (k,v) in my_dict1.items()]
print(my_list2)



#3.2.1 Total anual 
print('3.2.1- Total anual')
ventas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0]:
            var += id_venta[2]
            contador += 1
            if contador == 0:        
                ventas.extend([[id_venta[3][6:10], id_producto[2], var]])
            else:
                ventas.extend([[id_venta[3][6:10], id_producto[2], round(var/contador,2)]])
#Agrupación
my_dict1 = {}
for d in ventas:
    if d[0] in my_dict1.keys():
        my_dict1[d[0]] += d[1]
    else:
        my_dict1[d[0]] = d[1]

my_list2 = [[k,v] for (k,v) in my_dict1.items()]
print(my_list2)


#3.2.2-  Meses con más ventas al año
print('3.2.2- Meses con más ventas al año')
ventas=[]
for id_producto in lifestore_products:
    contador = 0
    var = 0
    for id_venta in lifestore_sales:
        if id_venta[1] == id_producto[0]:
            var += id_venta[2]
            contador += 1
            if contador == 0:        
                ventas.extend([[id_venta[3][3:10], id_producto[2], var]])
            else:
                ventas.extend([[id_venta[3][3:10], id_producto[2], round(var/contador,2)]])
ventas.sort(key=lambda ventita: ventita[0])

#Agrupación
my_dict1 = {}
for d in ventas:
    if d[0] in my_dict1.keys():
        my_dict1[d[0]] += d[1]
    else:
        my_dict1[d[0]] = d[1]
my_list2 = [[k,v] for (k,v) in my_dict1.items()]
print(my_list2)